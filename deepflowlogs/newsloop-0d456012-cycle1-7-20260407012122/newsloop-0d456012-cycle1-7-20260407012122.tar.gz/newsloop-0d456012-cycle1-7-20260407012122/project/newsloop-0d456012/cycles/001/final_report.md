# 近24小时国际新闻热点（终稿）

## 修改说明
- xhs: 体育娱乐和其他板块的短讯可以更紧凑，优先保留结果、时间和影响范围；图片条目要确保链接可直接访问。
- neko: 建议统一四个板块的主推语气，主推首句直接点明事件影响；检查主推图片是否足够稳定。
- 33: 政治经济和科技板块可再强化“为什么值得关注”的一句话，避免只罗列进展；副推之间尽量减少同源事件重复。

# 近24小时国际新闻热点

- workflow_id: intl-news-hotspots
- project_id: newsloop-0d456012
- cycle_no: 1
- run_id: 53cd35ab46f4
- 时区: Asia/Shanghai

## 政治经济
### 主推 | Key islands give Iran sway over the Strait of Hormuz.
- 来源: NYT > World News
- 发布时间: 2026-04-06T15:17:50+00:00
- 原文链接: https://www.nytimes.com/live/2026/world/us-israel-iran-attack-maps/key-islands-give-iran-sway-over-the-strait-of-hormuz
- 图片: 
据NYT > World News报道，这则政治经济新闻围绕“Key islands give Iran sway over the Strait of Hormuz.”展开，更多细节与背景请查看原文链接。

### 副推1 | Key islands give Iran sway over the Strait of Hormuz.
- 来源: NYT > World News
- 发布时间: 2026-04-06T15:17:50+00:00
- 原文链接: https://www.nytimes.com/live/2026/world/us-israel-iran-attack-maps/key-islands-give-iran-sway-over-the-strait-of-hormuz
- 图片: 
据NYT > World News报道，这则政治经济新闻围绕“Key islands give Iran sway over the Strait of Hormuz.”展开，更多细节与背景请查看原。

### 副推2 | Iran War Live Updates: As Trump’s New Ultimatum Looms, Tehran Vows to Step Up Attacks
- 来源: NYT > World News
- 发布时间: 2026-04-06T15:15:32+00:00
- 原文链接: https://www.nytimes.com/live/2026/04/06/world/iran-war-trump-israel
- 图片: 
据NYT > World News报道，这则政治经济新闻围绕“Iran War Live Updates: As Trump’s New Ultimatum Looms, Tehran Vows t。

### 其他 7 条
- Iran War Live Updates: As Trump’s New Ultimatum Looms, Tehran Vows to Step Up Attacks | NYT > World News | 2026-04-06T15:15:32+00:00 | https://www.nytimes.com/live/2026/04/06/world/iran-war-trump-israel | 据NYT > World News报道，这则政治经济新闻围绕“Iran War Live Upda。
- Here’s the latest. | NYT > World News | 2026-04-06T15:07:06+00:00 | https://www.nytimes.com/live/2026/04/06/world/iran-war-trump-israel/heres-the-latest | 据NYT > World News报道，这则政治经济新闻围绕“Here’s the latest。
- Here’s the latest. | NYT > World News | 2026-04-06T15:07:06+00:00 | https://www.nytimes.com/live/2026/04/06/world/iran-war-trump-israel/heres-the-latest | 据NYT > World News报道，这则政治经济新闻围绕“Here’s the latest。
- Trump’s Foreign Aid Overhaul Sent Millions More Dollars to Big U.S.-Based Contractors | NYT > World News | 2026-04-06T14:57:22+00:00 | https://www.nytimes.com/2026/04/06/health/trump-foreign-aid.html | 据NYT > World News报道，这则政治经济新闻围绕“Trump’s Foreign Ai。
- Trump’s Foreign Aid Overhaul Sent Millions More Dollars to Big U.S.-Based Contractors | NYT > World News | 2026-04-06T14:57:22+00:00 | https://www.nytimes.com/2026/04/06/health/trump-foreign-aid.html | 据NYT > World News报道，这则政治经济新闻围绕“Trump’s Foreign Ai。
- Trump Moves Deadline for Iran to Open Strait of Hormuz | NYT > World News | 2026-04-06T14:55:44+00:00 | https://www.nytimes.com/2026/04/06/world/middleeast/trump-threat-strait-peace.html | 据NYT > World News报道，这则政治经济新闻围绕“Trump Moves Deadli。
- Trump Moves Deadline for Iran to Open Strait of Hormuz | NYT > World News | 2026-04-06T14:55:44+00:00 | https://www.nytimes.com/2026/04/06/world/middleeast/trump-threat-strait-peace.html | 据NYT > World News报道，这则政治经济新闻围绕“Trump Moves Deadli。

## 科技
### 主推 | Logitech’s haptics-enhanced MX Master 4 mouse is on sale for under $100
- 来源: The Verge
- 发布时间: 2026-04-06T15:20:13+00:00
- 原文链接: https://www.theverge.com/gadgets/907302/logitech-mx-master-4-mouse-apple-macbook-air-m5-deal-sale
- 图片: https://platform.theverge.com/wp-content/uploads/sites/2/2026/04/mxmaster4deal.png?quality=90&strip=all&crop=0%2C10.732984293194%2C100%2C78.534031413613&w=1200, https://www.google-analytics.com/g/collect?v=2&tid=G-C3QZPB4GVE&cid=555&en=noscript_page_view, https://platform.theverge.com/wp-content/uploads/sites/2/chorus/author_profile_images/195800/CAMERON_FAULKNER.0.jpg?quality=90&strip=all&crop=0%2C0%2C100%2C100&w=2400
据The Verge报道，这则科技新闻围绕“Logitech’s haptics-enhanced MX Master 4 mouse is on sale for under $100”展开，更多细节与背景请查看原文链接。

### 副推1 | Cisco CEO Chuck Robbins wants data centers in space
- 来源: The Verge
- 发布时间: 2026-04-06T15:15:00+00:00
- 原文链接: https://www.theverge.com/podcast/906727/cisco-ceo-chuck-robbins-data-centers-space-ai-elon-musk-interview
- 图片: https://platform.theverge.com/wp-content/uploads/sites/2/2026/04/DCD-Chuck-Robbins-Cisco.jpg?quality=90&strip=all&crop=0%2C10.732984293194%2C100%2C78.534031413613&w=1200
据The Verge报道，这则科技新闻围绕“Cisco CEO Chuck Robbins wants data centers in space”展开，更多细节与背景请查看原文链接。

### 副推2 | Startup Battlefield 200 applications open: A chance for VC access, TechCrunch coverage, and $100K
- 来源: TechCrunch
- 发布时间: 2026-04-06T14:30:00+00:00
- 原文链接: https://techcrunch.com/2026/04/06/startup-battlefield-200-applications-open-get-vc-access-techcrunch-coverage-and-100k/
- 图片: https://techcrunch.com/wp-content/uploads/2024/05/sb200_trophy.png?w=1080
据TechCrunch报道，这则科技新闻围绕“Startup Battlefield 200 applications open: A chance for VC access, TechCrunc。

### 其他 7 条
- How to use the new ChatGPT app integrations, including DoorDash, Spotify, Uber, and others | TechCrunch | 2026-04-06T14:11:42+00:00 | https://techcrunch.com/2026/04/06/how-to-use-chatgpt-apps-doordash-spotify-uber/ | 据TechCrunch报道，这则科技新闻围绕“How to use the new ChatGPT。
- Ticket savings of up to $500 this week for TechCrunch Disrupt 2026 | TechCrunch | 2026-04-06T14:00:00+00:00 | https://techcrunch.com/2026/04/06/massive-ticket-savings-of-up-to-500-this-week-for-techcrunch-disrupt-2026/ | 据TechCrunch报道，这则科技新闻围绕“Ticket savings of up to $5。
- Used EV sales spike alongside gas prices | Ars Technica - All content | 2026-04-06T13:54:12+00:00 | https://arstechnica.com/cars/2026/04/used-ev-sales-spike-alongside-gas-prices/ | 据Ars Technica - All content报道，这则科技新闻围绕“Used EV sa。
- Convicted spyware maker Bryan Fleming avoids jail at sentencing | TechCrunch | 2026-04-06T13:03:04+00:00 | https://techcrunch.com/2026/04/06/convicted-spyware-maker-bryan-fleming-avoids-jail-at-sentencing/ | 据TechCrunch报道，这则科技新闻围绕“Convicted spyware maker Br。
- Spain’s Xoople raises $130 million Series B to map the Earth for AI | TechCrunch | 2026-04-06T13:00:00+00:00 | https://techcrunch.com/2026/04/06/spains-xoople-raises-130-million-series-b-to-map-the-earth-for-ai/ | 据TechCrunch报道，这则科技新闻围绕“Spain’s Xoople raises $130。
- Why will today's lunar flyby only beam back low-resolution video? | Ars Technica - All content | 2026-04-06T12:59:46+00:00 | https://arstechnica.com/space/2026/04/video-from-artemis-ii-flyby-of-the-moon-will-not-initially-look-spectacular/ | 据Ars Technica - All content报道，这则科技新闻围绕“Why will t。
- What Memento reveals about human nature, 25 years later | Ars Technica - All content | 2026-04-06T12:26:49+00:00 | https://arstechnica.com/culture/2026/04/memento-turns-25/ | 据Ars Technica - All content报道，这则科技新闻围绕“What Memen。

## 体育娱乐
### 主推 | Free agent pickups: Preseason promise, real fantasy results
- 来源: www.espn.com - TOP
- 发布时间: 2026-04-06T16:26:43+00:00
- 原文链接: https://www.espn.com/fantasy/baseball/story/_/id/48411997/fantasy-baseball-free-agent-pickups-waiver-wire-4-4-2026
- 图片: https://a3.espncdn.com/combiner/i?img=%2Fphoto%2F2026%2F0406%2Fr1639338_1296x729_16%2D9.jpg, https://www.espn.com/i/teamlogos/soccer/500/default-team-logo-500.png?h=100&w=100, https://a.espncdn.com/combiner/i?img=/i/columnists/full/cockcroft_tristan.png&h=80&w=80&scale=crop
据www.espn.com - TOP报道，这则体育娱乐新闻围绕“Free agent pickups: Preseason promise, real fantasy results”展开，更多细节与背景请查看原文链接。

### 副推1 | Trade offers for every first-round NFL draft pick: We made deals for J.J. McCarthy, Maxx Crosby
- 来源: www.espn.com - TOP
- 发布时间: 2026-04-06T15:27:22+00:00
- 原文链接: https://www.espn.com/nfl/draft2026/story/_/id/48373315/2026-nfl-mock-draft-all-trades-barnwell-deals-32-round-1-picks-players-mccarthy-crosby
- 图片: https://a.espncdn.com/combiner/i?img=%2Fphoto%2F2026%2F0406%2Fbarnwell_all_trades_nfl_mock_draft_new_1296x729.png
据www.espn.com - TOP报道，这则体育娱乐新闻围绕“Trade offers for every first-round NFL draft pick: We made deals f。

### 副推2 | Curry returns, puts Warriors 'back in the fight'
- 来源: www.espn.com - TOP
- 发布时间: 2026-04-06T15:25:27+00:00
- 原文链接: https://www.espn.com/nba/story/_/id/48409996/stephen-curry-puts-29-return-nearly-hands-warriors-win
- 图片: https://a3.espncdn.com/combiner/i?img=%2Fphoto%2F2026%2F0406%2Fr1639216_1296x729_16%2D9.jpg
据www.espn.com - TOP报道，这则体育娱乐新闻围绕“Curry returns, puts Warriors 'back in the fight'”展开，更多细节与背景请查看原文链接。

### 其他 7 条
- Flagg flips ROY odds after latest 'statement' game | www.espn.com - TOP | 2026-04-06T15:25:27+00:00 | https://www.espn.com/nba/story/_/id/48409452/flagg-passes-knueppel-roy-odds-statement-game | 据www.espn.com - TOP报道，这则体育娱乐新闻围绕“Flagg flips ROY。
- 📈 Masters tiers: Ranking favorites, contenders | www.espn.com - TOP | 2026-04-06T15:25:27+00:00 | https://www.espn.com/golf/story/_/id/48347092/masters-2026-ranking-favorites-contenders-rory-mcilroy-scottie-scheffler-bryson-dechambeau | 据www.espn.com - TOP报道，这则体育娱乐新闻围绕“📈 Masters tiers:。
- Sources: Michigan's May not pursuing other jobs | www.espn.com - TOP | 2026-04-06T15:25:27+00:00 | https://www.espn.com/mens-college-basketball/story/_/id/48407326/informs-michigan-not-pursuing-other-jobs | 据www.espn.com - TOP报道，这则体育娱乐新闻围绕“Sources: Michiga。
- Luka to seek care in Europe, aims for playoffs | www.espn.com - TOP | 2026-04-06T15:25:27+00:00 | https://www.espn.com/nba/story/_/id/48409097/luka-doncic-hamstring-seek-specialized-treatment-europe | 据www.espn.com - TOP报道，这则体育娱乐新闻围绕“Luka to seek car。
- 'We did it!': UCLA wins first women's NCAA title | www.espn.com - TOP | 2026-04-06T15:25:26+00:00 | https://www.espn.com/womens-college-basketball/story/_/id/48406646/ucla-blows-south-carolina-first-women-ncaa-title | 据www.espn.com - TOP报道，这则体育娱乐新闻围绕“'We did it!': UC。
- Staley praises Close: Happy for 'quality people' | www.espn.com - TOP | 2026-04-06T15:25:26+00:00 | https://www.espn.com/womens-college-basketball/story/_/id/48408286/staley-lauds-ucla-close-title-game-loss-auriemma-spat | 据www.espn.com - TOP报道，这则体育娱乐新闻围绕“Staley praises C。
- Badgers' Blackwell to hit portal, test draft process | www.espn.com - TOP | 2026-04-06T15:25:27+00:00 | https://www.espn.com/mens-college-basketball/story/_/id/48412067/wisconsin-blackwell-enter-portal-test-nba-draft-process | 据www.espn.com - TOP报道，这则体育娱乐新闻围绕“Badgers' Blackwe。

## 其他
### 主推 | Grants
- 来源: NASA
- 发布时间: 2026-04-06T15:22:30+00:00
- 原文链接: https://www.nasa.gov/centers-and-facilities/grants-2/
- 图片: https://www.nasa.gov/wp-content/themes/nasa/assets/images/nasa-logo@2x.png, https://www.nasa.gov/wp-content/uploads/2026/03/countdown.jpg?w=576, https://www.nasa.gov/wp-content/uploads/2026/03/suit-patch.jpg?w=1024
据NASA报道，这则其他新闻围绕“Grants”展开，更多细节与背景请查看原文链接。

### 副推1 | The Near Side of the Moon
- 来源: NASA
- 发布时间: 2026-04-06T14:59:19+00:00
- 原文链接: https://www.nasa.gov/image-article/the-near-side-of-the-moon/
- 图片: https://www.nasa.gov/wp-content/uploads/2026/04/art002e009057orig.jpg
据NASA报道，这则其他新闻围绕“The Near Side of the Moon”展开，更多细节与背景请查看原文链接。

### 副推2 | Young gray whale dies after swimming up river in Washington state
- 来源: BBC News
- 发布时间: 2026-04-06T11:25:32+00:00
- 原文链接: https://www.bbc.com/news/articles/cew7n4glz54o?at_medium=RSS&at_campaign=rss
- 图片: https://ichef.bbci.co.uk/news/1024/branded_news/2e9a/live/0d3d0ef0-31ab-11f1-a79a-77e93010d956.jpg
据BBC News报道，这则其他新闻围绕“Young gray whale dies after swimming up river in Washington state”展开，更多细节与背景请查。

### 其他 7 条
- 'We might look at the far side of the moon, and then change our socks' | BBC News | 2026-04-06T09:19:46+00:00 | https://www.bbc.com/news/videos/ce3d224zndvo?at_medium=RSS&at_campaign=rss | 据BBC News报道，这则其他新闻围绕“'We might look at the far si。
- For Many Patients Leaving the I.C.U., the Struggle Has Only Just Begun | NYT > Science | 2026-04-06T15:20:57+00:00 | https://www.nytimes.com/2026/04/04/health/post-icu-syndrome.html | 据NYT > Science报道，这则其他新闻围绕“For Many Patients Leavi。
- Federal Agency Unveils Three Potential Osteoarthritis Treatments | NYT > Science | 2026-04-06T15:00:12+00:00 | https://www.nytimes.com/2026/04/06/health/arpa-h-osteoarthritis-bone-cartilage.html | 据NYT > Science报道，这则其他新闻围绕“Federal Agency Unveils。
- Trump’s Foreign Aid Overhaul Sent Millions More Dollars to Big U.S.-Based Contractors | NYT > Science | 2026-04-06T14:57:22+00:00 | https://www.nytimes.com/2026/04/06/health/trump-foreign-aid.html | 据NYT > Science报道，这则其他新闻围绕“Trump’s Foreign Aid Ove。
- Artemis II Astronauts Will Set New Distance Record in Moon Flyby: What to Know | NYT > Science | 2026-04-06T14:32:34+00:00 | https://www.nytimes.com/2026/04/06/science/artemis-2-lunar-moon-flyby-nasa-timeline.html | 据NYT > Science报道，这则其他新闻围绕“Artemis II Astronauts W。
- NASA Families Don’t Go to the Moon, but They’re on the Mission, Too | NYT > Science | 2026-04-06T14:20:13+00:00 | https://www.nytimes.com/2026/04/06/science/artemis-moon-nasa-families-astronauts.html | 据NYT > Science报道，这则其他新闻围绕“NASA Families Don’t Go。
- NASA Artemis II Astronauts Race Into Moon’s Embrace After Quiet Easter | NYT > Science | 2026-04-06T13:44:10+00:00 | https://www.nytimes.com/2026/04/05/science/nasa-moon-artemis-day-5.html | 据NYT > Science报道，这则其他新闻围绕“NASA Artemis II Astrona。
