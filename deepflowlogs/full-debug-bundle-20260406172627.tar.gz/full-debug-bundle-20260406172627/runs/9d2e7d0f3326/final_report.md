# 近24小时国际新闻热点（终稿）

## 修改说明
- 已统一将标题和摘要转为中文表达
- 终稿按链接去重并优先选择带图素材
- 保留原始来源、发布时间、原文链接
- 工作流已覆盖一次打回重做和讨论阶段

# 近24小时国际新闻热点

- workflow_id: intl-news-hotspots
- run_id: 9d2e7d0f3326
- 时区: Asia/Shanghai

## 政治经济
### 主推 | 慈善机构“感受到能源价格上涨的压力”
- 来源: BBC News
- 发布时间: 2026-04-06T07:16:18+00:00
- 原文链接: https://www.bbc.com/news/articles/c937909n152o?at_medium=RSS&at_campaign=rss
- 图片: https://ichef.bbci.co.uk/news/1024/branded_news/c628/live/2b1e9610-30d8-11f1-9671-d707f9a5b2a4.jpg, https://static.files.bbci.co.uk/bbcdotcom/web/20260326-074245-a525cdfbda-web-2.43.1-1/grey-placeholder.png, https://ichef.bbci.co.uk/news/480/cpsprodpb/c628/live/2b1e9610-30d8-11f1-9671-d707f9a5b2a4.jpg.webp
菲利克斯项目是感受到伊朗冲突造成的成本增加影响的组织之一。

### 副推1 | 尽管伊朗战争存在不确定性，但旅游业仍面临“积极因素”
- 来源: BBC News
- 发布时间: 2026-04-06T06:15:20+00:00
- 原文链接: https://www.bbc.com/news/articles/cly7ngpgz5xo?at_medium=RSS&at_campaign=rss
- 图片: https://ichef.bbci.co.uk/news/1024/branded_news/8851/live/847b8ff0-2eb3-11f1-a1dd-1bb91a29c2db.jpg
老板们表示，今年的良好开局面临风险，但机会也出现了。

### 副推2 | 特朗普对伊朗充满咒骂的威胁后油价波动
- 来源: BBC News
- 发布时间: 2026-04-06T03:33:35+00:00
- 原文链接: https://www.bbc.com/news/articles/c8dl7g6e59eo?at_medium=RSS&at_campaign=rss
- 图片: https://ichef.bbci.co.uk/news/1024/branded_news/fefe/live/5f932e40-314d-11f1-b849-f5bf4267dd5c.jpg
布伦特原油价格上涨至 110 美元以上，但在美伊可能停火谈判的报道发布后，涨幅有所回落。

### 其他 7 条
- 斯蒂芬·库里伤愈复出拿下29分，但勇士输给了火箭 | Al Jazeera – Breaking News, World News and Video from Al Jazeera | 2026-04-06T06:09:38+00:00 | https://www.aljazeera.com/sports/2026/4/6/steph-curry-returns-from-injury-with-29-points-but-warriors-lose-to-rockets?traffic_source=rss | NBA 球星时隔九周复出，休斯顿火箭队在旧金山以 117-116 击败金州勇士队。
- 霍尔木兹海峡的新区域秩序 | Al Jazeera – Breaking News, World News and Video from Al Jazeera | 2026-04-06T05:40:17+00:00 | https://www.aljazeera.com/opinions/2026/4/6/a-new-regional-order-for-the-strait-of-hormuz?traffic_source=rss | 海湾合作委员会和伊朗可以为霍尔木兹海峡提出一个新的安全架构，为特朗普提供一个出口。
- 曼城队长席尔瓦将在赛季结束后离开英超俱乐部 | Al Jazeera – Breaking News, World News and Video from Al Jazeera | 2026-04-06T06:34:00+00:00 | https://www.aljazeera.com/sports/2026/4/6/man-city-captain-silva-to-leave-premier-league-club-at-seasons-end?traffic_source=rss | 席尔瓦在九年的任期内赢得了欧洲冠军联赛和六次英超联赛冠军后离开了曼城。
- 伊朗战争实时更新：特朗普发出新的霍尔木兹最后通牒后，以色列和伊朗进行贸易袭击 | NYT > World News | 2026-04-06T07:50:48+00:00 | https://www.nytimes.com/live/2026/04/06/world/iran-war-trump-israel | 周一早上的战斗发生在特朗普总统周二威胁称如果伊朗不开放霍尔木兹海峡就轰炸发电厂和桥梁之后。
- 这是最新的。 | NYT > World News | 2026-04-06T07:44:24+00:00 | https://www.nytimes.com/live/2026/04/06/world/iran-war-trump-israel/heres-the-latest | 这是最新的。
- 特朗普对伊朗发出最新威胁后油价小幅上涨 | NYT > Business | 2026-04-06T07:34:23+00:00 | https://www.nytimes.com/2026/04/06/business/oil-stocks-gas-prices-iran.html | 特朗普总统周日嘲笑伊朗领导人，威胁如果不重新开放霍尔木兹海峡，将升级袭击。
- 这不是中国的战争，但北京多年前就开始准备 | NYT > World News | 2026-04-06T04:01:09+00:00 | https://www.nytimes.com/2026/04/06/business/china-oil-shock-iran-war.html | 长期以来，中国一直担心地缘政治危机，当特朗普总统在其第一任期内加大投入时，中国加倍努力确保能源安全。

## 科技
### 主推 | 小米 17 Ultra 有一些令人印象深刻的附加功能，让拍照变得非常有趣
- 来源: TechCrunch
- 发布时间: 2026-04-06T07:00:00+00:00
- 原文链接: https://techcrunch.com/2026/04/06/xiaomi-17-ultra-review-camera-leica-specs-photography-kit-pro/
- 图片: https://techcrunch.com/wp-content/uploads/2026/04/Xiaomi-17-Ultra.jpg?resize=1200,675, https://techcrunch.com/wp-content/uploads/2024/09/tc-lockup.svg, https://techcrunch.com/wp-content/uploads/2024/09/tc-logo-mobile.svg
小米 17 Ultra 为您提供了大量的图像处理选项，包括预设滤镜和硬件附加组件。

### 副推1 | Polymarket 取消了与营救被击落空军军官有关的投注
- 来源: TechCrunch
- 发布时间: 2026-04-05T19:36:03+00:00
- 原文链接: https://techcrunch.com/2026/04/05/polymarket-took-down-wagers-tied-to-rescue-of-downed-air-force-officer/
- 图片: https://techcrunch.com/wp-content/uploads/2026/03/GettyImages-2259602005.jpg?w=1024
一名民主党国会议员严厉批评 Polymarket 允许用户押注美国确认营救在伊朗上空被击落的空军军人的日期。

### 副推2 | 根据微软的使用条款，Copilot“仅用于娱乐目的”
- 来源: TechCrunch
- 发布时间: 2026-04-05T18:51:37+00:00
- 原文链接: https://techcrunch.com/2026/04/05/copilot-is-for-entertainment-purposes-only-according-to-microsofts-terms-of-service/
- 图片: https://techcrunch.com/wp-content/uploads/2024/04/GettyImages-2041281128-e1712563728365.jpg?resize=1200,676
人工智能怀疑论者并不是唯一警告用户不要不假思索地相信模型输出的人——人工智能公司在服务条款中也是这么说的。

### 其他 7 条
- Los Thuthanaka 的 Wak’a 是去年 Pitchfork 最爱的惊喜作品的更柔和的后续作品 | The Verge | 2026-04-05T18:30:00+00:00 | https://www.theverge.com/entertainment/907174/los-thuthanaka-waka-review | 去年，Los Thuthanaka 凭借他们的同名首张专辑横空出世，夺得了 Pitchfork 的。
- 当人们寻找结交新朋友的方法时，以下这些应用程序有望提供帮助 | TechCrunch | 2026-04-05T18:01:37+00:00 | https://techcrunch.com/2026/04/05/as-people-look-for-ways-to-make-new-friends-here-are-the-apps-promising-to-help/ | 我们编制了一份友谊应用程序列表，从 BFF 之类的朋友发现平台到 Timeleft 之类的以活动为。
- TechCrunch Mobility：“透明度严重缺乏” | TechCrunch | 2026-04-05T16:05:00+00:00 | https://techcrunch.com/2026/04/05/techcrunch-mobility-a-stunning-lack-of-transparency/ | 欢迎回到 TechCrunch Mobility——您获取关于未来交通的新闻和见解的中心枢纽。时间
- Suno 是音乐版权的噩梦 | The Verge | 2026-04-05T16:00:00+00:00 | https://www.theverge.com/ai-artificial-intelligence/906896/sunos-copyright-ai-music-covers | AI音乐平台Suno的政策是不允许使用受版权保护的材料。您可以上传自己的曲目进行混音，或将原始歌词。
- 轨道数据中心能否帮助证明 SpaceX 的巨额估值是合理的？ | TechCrunch | 2026-04-05T15:40:58+00:00 | https://techcrunch.com/2026/04/05/can-orbital-data-centers-help-justify-a-massive-valuation-for-spacex/ | 在 TechCrunch 股票播客的最新一集中，我们讨论了埃隆·马斯克 (Elon Musk) 对。
- 在日本，机器人不是来代替你的工作的，而是来代替你的。它填补了没人想要的那个 | TechCrunch | 2026-04-05T14:00:00+00:00 | https://techcrunch.com/2026/04/05/japan-is-proving-experimental-physical-ai-is-ready-for-the-real-world/ | 在劳动力短缺的推动下，日本正在将物理人工智能从试点项目推向现实世界的部署。
- 我让 Google 地图中的 Gemini 计划我的一天，结果出奇地顺利 | The Verge | 2026-04-05T14:00:00+00:00 | https://www.theverge.com/tech/907015/gemini-google-maps-hands-on | 您可能对 Gemini 很熟悉，因为您使用的每项 Google 服务中都包含 Gemini - 无。

## 体育娱乐
### 主推 | 韩国票房：《万福玛丽计划》取代《国王的守望者》登上第一宝座
- 来源: Variety
- 发布时间: 2026-04-06T07:44:10+00:00
- 原文链接: https://variety.com/2026/film/box-office/korea-box-office-project-hail-mary-no-1-the-kings-warden-1236709170/
- 图片: https://variety.com/wp-content/uploads/2026/03/PHM_36568_R2.jpg?crop=0px%2C185px%2C4496px%2C2531px&resize=1000%2C563, https://sb.scorecardresearch.com/p?c1=2&c2=6035310&c4=&cv=3.9&cj=1, https://variety.com/wp-content/uploads/2026/03/PHM_36568_R2.jpg?w=1000&h=667&crop=1
2026 年 4 月 3 日至 5 日的周末，《万福玛丽计划》跃居韩国票房榜首。根据韩国电影振兴委员会运营的追踪服务 KOBIS 的数据，该影片在 328,750 场观影中获得了 240 万美元的票房收入，占据了 39.56% 的收入份额。自 3 月 18 日首映以来，这部电影 […]

### 副推1 | 中国票房：《超级马里奥银河大电影》登顶榜首
- 来源: Variety
- 发布时间: 2026-04-06T07:04:35+00:00
- 原文链接: https://variety.com/2026/film/box-office/china-box-office-the-super-mario-galaxy-movie-1236709168/
- 图片: https://variety.com/wp-content/uploads/2026/04/MCDSUMA_UV092.jpg?crop=404px%2C0px%2C2236px%2C1257px&resize=1000%2C563
根据 Artisan Gateway 的数据，环球影业出品的《超级马里奥银河大电影》在 4 月 3 日至 5 日周末飙升至中国票房榜首，首映票房收入为 5710 万元人民币（合 830 万美元）。中。

### 副推2 | 《星球大战：摩尔 — 暗影领主》是《克隆人战争》传奇的一个参差不齐但充满希望的延伸：电视评论
- 来源: Variety
- 发布时间: 2026-04-06T07:01:00+00:00
- 原文链接: https://variety.com/2026/tv/reviews/star-wars-maul-shadow-lord-review-clone-wars-1236706487/
- 图片: https://variety.com/wp-content/uploads/2026/04/MAUL_Trailer1_Still_16.jpg?w=1000&h=563&crop=1
下个月，《星球大战》系列电影将在阔别七年之后重返影院，由乔恩·费儒执导的《曼达洛人和格罗古》，该片是该导演热门 Disney+ 系列剧《曼达洛人》的衍生剧。首映证实了粉丝们已经很清楚的事情：自 20。

### 其他 7 条
- 《死亡面孔》评论：一部 70 年代风格的 B 级恐怖电影迎合了人们对“真实”恐怖片日益增长的胃口 | Variety | 2026-04-06T03:30:11+00:00 | https://variety.com/2026/film/reviews/faces-of-death-review-1236706326/ | 像亚瑟这样的疯子不仅仅是一个连环杀手，他还是新的随心所欲的注意力经济的一部分！ ——这是一个具有挑。
- 《死亡面孔》评论：芭比·费雷拉和戴克·蒙哥马利无缘无故的恐怖翻拍 | The Hollywood Reporter | 2026-04-06T03:30:00+00:00 | https://www.hollywoodreporter.com/movies/movie-reviews/faces-of-death-review-barbie-ferreira-dacre-montgomery-1236554535/ | 海尔默·丹尼尔·戈德哈伯 (Daniel Goldhaber) 的电影《如何炸毁管道》的灵感源自。
- 萨凡纳·格思里 (Savannah Guthrie) 质疑耶稣在妈妈南希失踪期间是否“经历过我所感受到的这种特殊的创伤” | The Hollywood Reporter | 2026-04-06T02:53:14+00:00 | https://www.hollywoodreporter.com/tv/tv-news/savannah-guthrie-jesus-nancy-disappearance-easter-message-1236556318/ | 这位“今日”联合主持人在复活节视频信息中向她的纽约好牧人教会教区居民传达了这一信息。
- 《黑暗之风》大结局结束了一个案件，然后以一场令人震惊的谋杀案结束 | The Hollywood Reporter | 2026-04-06T02:00:00+00:00 | https://www.hollywoodreporter.com/tv/tv-features/dark-winds-finale-season-4-shocking-murder-interviews-1236554805/ | 在结局中，有人“穿着靴子”死去，这改变了乔·利弗恩和纳瓦霍部落警察其他成员的游戏规则。该节目的团队。
- “罗德岛的真正家庭主妇”：阿什莉·亚科内蒂重返真人秀以及为什么泰勒·弗兰基·保罗永远不应该成为“单身女郎” | Variety | 2026-04-06T02:00:00+00:00 | https://variety.com/2026/tv/news/ashley-iaconetti-real-housewives-rhode-island-bachelor-1236705948/ | 自从《单身汉》演员阿什利·亚科内蒂被宣布成为布拉沃电视台《罗德岛真正的家庭主妇》的七位女主播之一以。
- Charli xcx 管理层澄清 Sky Ferreira 关于《呼啸山庄》制作人员的说法 | Billboard | 2026-04-06T01:31:21+00:00 | https://www.billboard.com/music/music-news/charli-xcx-sky-ferreira-wuthering-heights-credit-statement-1236215575/ | 在 Sky Ferreira 声称她的旧样带被未经授权用于 Charli xcx 的《呼啸山庄》专。
- 米茨基为好莱坞高中的重要驻场演出带来狂热与宁静：音乐会回顾 | Variety | 2026-04-06T01:21:59+00:00 | https://variety.com/2026/music/concert-reviews/mitski-hollywood-high-school-concert-review-2-1236709091/ | 上周，米茨基在好莱坞高中举行了一场为期五晚的演出，任何可能进入学校礼堂观看演出的老师一定会疯狂地嫉。

## 其他
### 主推 | 阿耳忒弥斯号船员与地球失去联系的40分钟
- 来源: BBC News
- 发布时间: 2026-04-05T23:02:53+00:00
- 原文链接: https://www.bbc.com/news/articles/cj0vyzmmy50o?at_medium=RSS&at_campaign=rss
- 图片: https://ichef.bbci.co.uk/news/1024/branded_news/62f7/live/d3a93f70-2fb0-11f1-9885-91ba338bedfd.jpg, https://static.files.bbci.co.uk/bbcdotcom/web/20260326-074245-a525cdfbda-web-2.43.1-1/grey-placeholder.png, https://ichef.bbci.co.uk/news/480/cpsprodpb/62f7/live/d3a93f70-2fb0-11f1-9885-91ba338bedfd.jpg.webp
当宇航员经过月球后面时，由于与地球的通讯被阻断，他们将经历一段沉默和孤独的时刻。

### 副推1 | 阿耳忒弥斯二号宇航员在前往月球的途中遇到了厕所问题
- 来源: BBC News
- 发布时间: 2026-04-05T18:35:24+00:00
- 原文链接: https://www.bbc.com/news/articles/c87wy05wr4no?at_medium=RSS&at_campaign=rss
- 图片: https://ichef.bbci.co.uk/news/1024/branded_news/1364/live/76cc98f0-310a-11f1-b297-95b0a0a8331e.jpg
阿耳忒弥斯二号任务猎户座太空舱上的四名宇航员在航天器的厕所上遇到了间歇性的并发症。

### 副推2 | 阿耳忒弥斯令人惊叹的月球照片 - 科学照片还是度假照片？
- 来源: BBC News
- 发布时间: 2026-04-05T15:03:19+00:00
- 原文链接: https://www.bbc.com/news/articles/clye6j0g840o?at_medium=RSS&at_campaign=rss
- 图片: https://ichef.bbci.co.uk/news/1024/branded_news/bfde/live/0c742dd0-30f4-11f1-b6e3-bf199a2978e2.jpg
这些美丽图片背后的故事从阿耳忒弥斯二号宇航员传回地球。

### 其他 7 条
- 想你，地球 | NASA | 2026-04-05T14:04:33+00:00 | https://www.nasa.gov/image-article/thinking-of-you-earth/ | 2026 年 4 月 4 日，当宇航员前往月球时，美国宇航局宇航员兼阿耳忒弥斯二号指挥官里德·怀斯。
- 阿尔忒弥斯二号飞越月球：机组人员、时间表和须知 | NYT > Science | 2026-04-06T04:01:15+00:00 | https://www.nytimes.com/2026/04/06/science/artemis-2-lunar-moon-flyby-nasa-timeline.html | 三名美国人和一名加拿大人的绕月之旅已进入第六天，但现在开始还为时不晚。
- 美国宇航局阿耳忒弥斯二号宇航员在安静的复活节后奔向月球的怀抱 | NYT > Science | 2026-04-06T03:20:18+00:00 | https://www.nytimes.com/2026/04/05/science/nasa-moon-artemis-day-5.html | 在周一飞越月球之前，机组人员庆祝了宇航员杰里米·汉森的首次太空飞行，并收到了阿波罗 16 号月球漫。
